package br.edu.ifpr.teste;

import java.util.ArrayList;
import java.util.List;

public class Teste {

    public List<String> listarContatos(){
        List<String> lista = new ArrayList<String>();

        lista.add("ana");
        lista.add("joab");
        lista.add("maria");
        lista.add("Jefferson");

        return lista;
    }

}
